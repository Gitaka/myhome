<!DOCTYPE html>
<html>
   <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
      <title>MyHome.co.ke</title>

       <link rel="stylesheet" href="{{asset('bootstrap.min.css')}}">
   
   </head>
   <body>

             <div class="logo">
                  <a href="/"><img src="{{asset('images/logo2.png')}}" title="logo" /></a>
             </div>
             <h1>404 Page Not Found</h1>
          
   </body>
  
</html>