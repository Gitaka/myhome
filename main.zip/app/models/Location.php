<?php
class Location extends eloquent{
	public $table= 'locations';

}

?>