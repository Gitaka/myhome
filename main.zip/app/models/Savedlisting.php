<?php
class Savedlisting extends Eloquent{
	 protected $table='savedlistings';
	 public $fillable=array('userId','listingId');
	
}

?>