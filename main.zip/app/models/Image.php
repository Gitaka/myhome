<?php
class size extends Eloquent{
      public $table="sizes";

    protected $fillable=array('path','ext');
 	public $timestamps=false;

 

 	  
   }
?>