<?php


 class Admin extends Eloquent {
 

 	 protected $table='admins';
 	 public $fillable=array('nama','password','email');


 }
 
?>